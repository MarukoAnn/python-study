def recevie():
    return "这是来自 100xx得短信"
